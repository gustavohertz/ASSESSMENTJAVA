package com.example.demoST;

public class PokemonNotFoundException extends RuntimeException {
    public PokemonNotFoundException(String s) {
        super(s);
    }
}

