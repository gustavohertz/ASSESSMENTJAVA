package com.example.demoST;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PokemonService {

    private final List<Pokemon> pokemonList = new ArrayList<>();

    public void createPokemon(Pokemon pokemon) {
        // Lógica para criar um novo Pokemon
        pokemonList.add(pokemon);
    }

    public List<Pokemon> getAllPokemon() {
        // Lógica para obter todos os Pokemon
        return pokemonList;
    }

    public Pokemon getPokemonById(Long id) {
        // Lógica para obter um Pokemon por ID
        return pokemonList.stream()
                .filter(pokemon -> pokemon.getId(id).equals(id))
                .findFirst()
                .orElse(null);
    }

    public void updatePokemon(Long id, Pokemon updatedPokemon) {
        // Lógica para atualizar um Pokemon por ID
        Pokemon existingPokemon = getPokemonById(id);
        if (existingPokemon != null) {
            existingPokemon.setName(updatedPokemon.getName());
            existingPokemon.setHeight(updatedPokemon.getHeight());
            existingPokemon.setMoves(updatedPokemon.getMoves());
        }
    }

    public void deletePokemon(Long id) {
        // Lógica para excluir um Pokemon por ID
        pokemonList.removeIf(pokemon -> pokemon.getId(id).equals(id));
    }
}
